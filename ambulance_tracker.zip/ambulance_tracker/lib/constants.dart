import 'package:flutter/material.dart';

//const kPrimaryColor = Color(0xFF6F35A5);
const kPrimaryColor = Color(0xFF5C6BC0);

const kPrimaryLightColor = Color(0xFFEDE7F6);